export const Usuarios = [
    {   
    Nombre : "Usuario1",
    Id : 0,
    Img : "https://tse1.mm.bing.net/th/id/OIP.we4cd4LJtKho8QgIo0hdWQHaFj?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3", 
    Calendario: {
        2025 : {
            1 : {},
            2 : {},
            3 : {},
            52 : {
                1 : [   { Nombre : "Desayuno, Almuerzo, once, etc..; El id es el id de la receta",
                          Porciones : 2,
                          id : 23920},
                        { Nombre : "Desayuno, Almuerzo, once, etc..; El id es el id de la receta",
                          Porciones : 2,
                          id : 23920},
                        {},
                        {},
                        {},
                        {},
                        {},
                ], 
              }
        }
    }
    },
    {   
    "Nombre" : "Usuario2",
    "Id" : 1,
    "Img" : "https://tse3.mm.bing.net/th/id/OIP.LTMrPUU8IkEeDAB6RjQO-wHaFe?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3", 
    "Calendario": {
        "2025" : {
            "1" : {},
            "2" : {},
            "3" : {},
            "52" : {
                "1" : [ { "Nombre" : "Desayuno, Almuerzo, once, etc..; El id es el id de la receta",
                                "Porciones" : 2,
                                "id" : 23920},
                        {},
                        {},
                        {},
                        {},
                        {},
                        {},
                ]
              }
        }
    }
    },     
]